package com.ashok.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ashok.entity.CitizenDataCollectionEntity;

public interface CitizenDataCollectionRepo extends JpaRepository<CitizenDataCollectionEntity, Integer> {
	
	
	
}
