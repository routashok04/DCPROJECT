/**
 * 
 */
package com.ashok.service;

import java.util.List;

import com.ashok.binding.EduactionDetailsEntity;
import com.ashok.binding.IncomeDetailsEntity;
import com.ashok.binding.KidsDetailsEntity;
import com.ashok.entity.CitizenDataCollectionEntity;


public interface CitizenDataCollectionService {
	
	
		public boolean findAppId(Integer appId);
		
		
		public Integer caseNumberCreation(Integer caseId);
		
	
		public IncomeDetailsEntity incomeDeatils(IncomeDetailsEntity incomeDetails);
		
		
		public EduactionDetailsEntity educationDeatils(EduactionDetailsEntity eduactionDetails);
		
		
		public List<KidsDetailsEntity> kidsDetails(KidsDetailsEntity kidsDetails);
		
		public CitizenDataCollectionEntity getCitizenDataCollection(Integer caseId);
}
